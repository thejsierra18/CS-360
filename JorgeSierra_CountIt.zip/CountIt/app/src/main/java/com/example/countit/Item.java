package com.example.countit;

public class Item {
    private int id;
    private String name;
    private int number;
    private int quantity;

    public Item(){}

    public Item(int id, String name, int number, int quantity) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.quantity = quantity;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    //Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public int getQuantity() {
        return quantity;
    }
}
