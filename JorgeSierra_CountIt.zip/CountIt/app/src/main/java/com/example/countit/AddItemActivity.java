package com.example.countit;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    private AppDatabase appDatabase;
    private EditText addName;
    private EditText addNumber;
    private EditText addQuantity;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        appDatabase = appDatabase.getInstance(getApplicationContext());

        addName = findViewById(R.id.addItemName);
        addNumber = findViewById(R.id.addItemNumber);
        addQuantity = findViewById(R.id.addItemQuantity);
        addButton = findViewById(R.id.addItemButton);

        addButton.setOnClickListener(addOCL);

    }

    // Ensuring user input is valid
    private final View.OnClickListener addOCL = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (isValid()) {
                addItem();
                Intent intent = new Intent(AddItemActivity.this, InventoryScreenActivity.class);
                startActivity(intent);
            } else {
                Context context =  getApplicationContext();
                CharSequence error= "Invalid input. Please try again.";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, error, duration);
                toast.show();
            }
        }
    };

    public void addItem() {
        Item newItem = new Item(-1, addName.getText().toString(), Integer.parseInt(addNumber.getText().toString()), Integer.parseInt(addQuantity.getText().toString()));
        appDatabase.addItem(newItem);
    }

    private boolean isValid() {
        String name = addName.getText().toString();
        int number;
        int quantity;
        boolean isValid = true;

        try {
            number = Integer.parseInt(addNumber.getText().toString());
            quantity = Integer.parseInt(addQuantity.getText().toString());
        }
        catch (NumberFormatException e) {
            return false;
        }

        if (name.isEmpty() || number < 0 || quantity < 0) {
            isValid = false;
        }

        return isValid;
    }
}
