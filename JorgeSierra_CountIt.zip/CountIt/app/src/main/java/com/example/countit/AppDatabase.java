package com.example.countit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class AppDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "countit.db";
    private static final int VERSION = 1;

    private static AppDatabase mAppDb;

    public static AppDatabase getInstance(Context context) {
        if (mAppDb == null) {
            mAppDb = new AppDatabase(context);
        }
        return mAppDb;
    }

    private AppDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_PHONE = "phone";
    }

    private static final class ItemsTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_NUMBER = "number";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + ", " +
                UserTable.COL_PASSWORD + ", " +
                UserTable.COL_PHONE + ")");

        // Create items table
        db.execSQL("create table " + ItemsTable.TABLE +  " (" +
                ItemsTable.COL_ID + " integer primary key autoincrement, " +
                ItemsTable.COL_NAME + ", " +
                ItemsTable.COL_NUMBER + " int, " +
                ItemsTable.COL_QUANTITY + " int)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + ItemsTable.TABLE);
        onCreate(db);
    }

    public void addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        db.insert(UserTable.TABLE, null, values);
    }

    public User getUser(User user) {
        SQLiteDatabase db = getReadableDatabase();
        User foundUser = null;
        String query = "select * from " + UserTable.TABLE + " where " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[] {user.getUsername()});

        if (cursor.moveToFirst()) {
            foundUser = new User();
            foundUser.setUsername(cursor.getString(1));
            foundUser.setPassword(cursor.getString(2));
        }
        return foundUser;
    }

    public void addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ItemsTable.COL_NAME, item.getName());
        values.put(ItemsTable.COL_QUANTITY, item.getQuantity());

        db.insert(ItemsTable.TABLE, null, values);
    }

    public List<Item> getItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select * from " + ItemsTable.TABLE;

        Cursor cursor = db.rawQuery(query, null,null);
        if(cursor.moveToFirst()) {
            do {
                Item newItem = new Item(cursor.getInt(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3));
                itemList.add(newItem);
            }
            while(cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }

    public void increaseQuantity(int id, int currentCount) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemsTable.COL_QUANTITY, currentCount+1);
        db.update(ItemsTable.TABLE, values, "_id = ?", new String[] {Integer.toString(id)});
    }

    // Decrease quantity, if quantity goes below 0 delete item
    public void decreaseQuantity(int id, int currentCount) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        if (currentCount == 0) {
            deleteInventory(id);
        } else {
            values.put(ItemsTable.COL_QUANTITY, currentCount-1);
        }
        db.update(ItemsTable.TABLE, values, "_id = ?", new String[] {Integer.toString(id)});
    }

    public void deleteInventory(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemsTable.TABLE, ItemsTable.COL_ID + " = " + id, null);
    }
}
