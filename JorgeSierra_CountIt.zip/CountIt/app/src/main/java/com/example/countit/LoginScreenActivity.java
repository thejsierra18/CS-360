package com.example.countit;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginScreenActivity extends AppCompatActivity {

    private AppDatabase appDatabase;
    private EditText username;
    private EditText password;
    private Button signIn;
    private Button register;
    private TextView loginError;
    private TextView registerError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        appDatabase = appDatabase.getInstance(getApplicationContext());

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        signIn = findViewById(R.id.signin);
        register = findViewById(R.id.register);
        loginError = findViewById(R.id.loginError);
        registerError = findViewById(R.id.registerError);

        signIn.setOnClickListener(signInOCL);
        register.setOnClickListener(registerOCL);

        getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS);

    }

    // Throw error if sign in credentials are invalid
    private final View.OnClickListener signInOCL = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (verifyLogin()) {
                Intent intent = new Intent(LoginScreenActivity.this, InventoryScreenActivity.class);
                startActivity(intent);
            } else {
                loginError.setVisibility(TextView.VISIBLE);
                Handler handler = new Handler();
                handler.postDelayed(() -> loginError.setVisibility(TextView.INVISIBLE), 10000);
            }

        }
    };

    // Throw error if user tries to register an existent Username
    private final View.OnClickListener registerOCL = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (!userExists()) {
                addUser();
                Intent intent = new Intent(LoginScreenActivity.this, LoginScreenActivity.class);
                startActivity(intent);
            } else {
                registerError.setVisibility(TextView.VISIBLE);
                Handler handler = new Handler();
                handler.postDelayed(() -> registerError.setVisibility(TextView.INVISIBLE), 10000);
            }
        }
    };

    public void addUser() {
        User newUser = new User(username.getText().toString(), password.getText().toString());
        appDatabase.addUser(newUser);
    }

    private boolean userExists() {
        User tempUser = new User(username.getText().toString(), password.getText().toString());
        return appDatabase.getUser(tempUser) != null;
    }

    private boolean verifyLogin() {
        User tempUser = new User(username.getText().toString(), password.getText().toString());
        User existentUser = appDatabase.getUser(tempUser);

        if (existentUser != null) {
            return tempUser.getPassword().equals(existentUser.getPassword());
        } else {
            return false;
        }
    }
}