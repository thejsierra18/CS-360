package com.example.countit;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryRecycle extends RecyclerView.Adapter<InventoryRecycle.MyViewHolder> {
    private final Context context;

    private final List<Item> itemsList;

    private final AppDatabase appDatabase;

    public InventoryRecycle(Context c, List<Item> items, AppDatabase db) {
        context = c;
        itemsList = items;
        appDatabase = db;
    }

    // View holder for inventory_item.xml
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.inventory_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.itemName.setText(itemsList.get(position).getName());
        holder.itemCount.setText(String.valueOf(itemsList.get(position).getQuantity()));

        // Increase
        holder.increase.setOnClickListener(v -> {
            Intent intent = new Intent(context, InventoryScreenActivity.class);
            appDatabase.increaseQuantity(itemsList.get(position).getId(), itemsList.get(position).getQuantity());
            context.startActivity(intent);
        });

        // Decrease
        holder.decrease.setOnClickListener(v -> {
            Intent intent = new Intent(context, InventoryScreenActivity.class);
            appDatabase.decreaseQuantity(itemsList.get(position).getId(), itemsList.get(position).getQuantity());

            if(itemsList.get(position).getQuantity() - 1 == 0) {  // Send SMS if quantity is zero
                if(context.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) // Check to make sure permissions are enabled to send SMS
                    sendSMS(itemsList.get(position).getName());
            }
            context.startActivity(intent);
        });

        // deletes an item
        holder.remove.setOnClickListener(v -> {
            Intent intent = new Intent(context, InventoryScreenActivity.class);
            appDatabase.deleteInventory(itemsList.get(position).getId());
            context.startActivity(intent);
        });
    }

    // Refresh inventory screen with updated values
    @Override
    public int getItemCount() {
        return itemsList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemCount;
        Button increase, decrease, remove;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemCount = itemView.findViewById(R.id.itemCount);
            remove = itemView.findViewById(R.id.removeButton);
            increase = itemView.findViewById(R.id.increaseButton);
            decrease = itemView.findViewById(R.id.decreaseButton);
        }
    }


    // Send sms alert
    private void sendSMS(String item) {
        String phone = "15555215554";
        String message = "Item: " + item + " is out of stock.";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phone, null, message, null, null);
    }
}
