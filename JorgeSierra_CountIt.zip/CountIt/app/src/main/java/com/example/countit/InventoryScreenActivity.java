package com.example.countit;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;



public class InventoryScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_screen);

        Button addInventory = findViewById(R.id.addButton);

        AppDatabase appDatabase = AppDatabase.getInstance(getApplicationContext());

        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        InventoryRecycle myAdapter = new InventoryRecycle(this, appDatabase.getItems(), appDatabase);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        addInventory.setOnClickListener(addItemOnClickListener);

        // Check for SMS permissions and request if not granted
        if(getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(this, "Permission Granted", Toast.LENGTH_LONG);
        }
        else{
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);  // Pop up asking for permission to receive SMS
        }
    }


    private final View.OnClickListener addItemOnClickListener = v -> {
        Intent intent = new Intent(InventoryScreenActivity.this, AddItemActivity.class);
        startActivity(intent);

    };

}

